# TAIS
Problemas del juez de la asignatura TAIS - Facultad de informática de la 
Universidad Complutense de Madrid

Curso 2018 - 2019

Autor: Mauricio Abbati Loureiro

Desarrollados en C++
