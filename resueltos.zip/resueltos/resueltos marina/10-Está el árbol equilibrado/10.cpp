﻿
// Marina Lozano Lahuerta

#include <iostream>
#include <fstream>
#include "bintree_eda.h"

struct tSol{
	bool equi;
	int altura;
};

// función que resuelve el problema
tSol equilibrado(bintree<char> t) {
	if (t.empty()){
		return{true, 0};
	}
	else{
		tSol iz = equilibrado(t.left());
		tSol dr = equilibrado(t.right());

		bool eq = false;

		if (iz.equi && dr.equi){
			if (iz.altura == dr.altura || iz.altura + 1 == dr.altura || iz.altura == dr.altura + 1){
				eq = true;
			}
		}
		
		int altura = std::max(iz.altura, dr.altura) + 1;

		return{ eq, altura };
	}
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {

	// leer los datos de la entrada
	bintree<char> tree = leerArbol('.');


	tSol sol = equilibrado(tree);

	// escribir solución

	if (sol.equi) std::cout << "SI\n";
	else std::cout << "NO\n";
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	int numCasos;
	std::cin >> numCasos;
	for (int i = 0; i < numCasos; ++i)
		resuelveCaso();

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
