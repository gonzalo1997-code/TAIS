
// Marina Lozano Lahuerta

#include <iostream>
#include <fstream>
#include "bintree_eda.h"

struct tSol{
	bool avl;
	int altura;
	int min;
	int max;
};


tSol esAVL(bintree<int> t) {
	if (t.left().empty() && t.right().empty()){
		return{ true, 1, t.root(), t.root() };
	}
	else if (t.left().empty()){
		tSol dr = esAVL(t.right());

		return{ dr.altura == 1 && dr.avl && t.root() < dr.min, dr.altura + 1, std::min(dr.min, t.root()), std::max(dr.max, t.root()) };
	}
	else if (t.right().empty()){
		tSol iz = esAVL(t.left());

		return{ iz.altura == 1 && iz.avl && t.root() > iz.max, iz.altura + 1, std::min(iz.min, t.root()), std::max(iz.max, t.root()) };
	}
	else{
		tSol iz = esAVL(t.left());
		tSol dr = esAVL(t.right());

		bool avl = false;
		if (iz.altura == dr.altura || iz.altura + 1 == dr.altura || iz.altura == dr.altura + 1){
			if (iz.avl && dr.avl && t.root() > iz.max && t.root() < dr.min)
			avl = true;
		}

		int alt = std::max(iz.altura, dr.altura) + 1;

		return{ avl, alt, std::min(t.root(), std::min(iz.min, dr.min)), std::max(t.root(), std::max(iz.max, dr.max)) };
	}

}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
void resuelveCaso() {

	// leer los datos de la entrada
	bintree<int> tree = leerArbol(-1);
	if (!tree.empty()){
		tSol sol = esAVL(tree);

		// escribir soluci�n

		if (sol.avl){
			std::cout << "SI\n";
		}
		else{
			std::cout << "NO\n";
		}
	}
	else{
		std::cout << "SI\n";
	}
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	int numCasos;
	std::cin >> numCasos;
	for (int i = 0; i < numCasos; ++i)
		resuelveCaso();

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
