
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

/*
	Utilizando una cola de prioridad se van cogiendo elementos de 2 en 2
	para sumarlos, el resultado de esa suma se vuelve a meter en la cola.
	De esta manera, se van sumando los dos elementos menores hasta que no queden 
	m�s.
*/

#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <functional>

// comentario sobre el coste, O(f(N)), donde N es ...


// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	long int N;

	std::cin >> N;

	if (N == 0)
		return false;


	std::priority_queue<long int, std::vector<long int>, std::greater<long int>>  p;
	long int elem;

	for (int i = 0; i < N; ++i){
		std::cin >> elem;
		p.push(elem);
	}

	long int suma = 0;
	long int esfuerzo = 0;
	long int elem1, elem2;

	while (p.size() > 1){
		elem1 = p.top();
		p.pop();
		elem2 = p.top();
		p.pop();

		suma = elem1 + elem2;
		esfuerzo += suma;
		if (!p.empty())
			p.push(suma);

	}


	// escribir sol
	std::cout << esfuerzo << "\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
