
// Marina Lozano Lahuerta
// TAIS41

#include <iostream>
#include <fstream>
#include "PriorityQueue.h"


struct usuario{
	int identificador;
	int periodo;
	int tiempoAct;
};


bool operator < (usuario const& u1, usuario const& u2){
	if (u1.tiempoAct < u2.tiempoAct) return true;
	else{
		if (u1.tiempoAct == u2.tiempoAct){
			if (u1.identificador < u2.identificador)
				return true;
		}
	}

	return false;
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada

	int numUsu;

	std::cin >> numUsu;
	if (numUsu==0)
		return false;

	int id, tiempo;
	PriorityQueue<usuario> p;

	for (int i = 0; i < numUsu; ++i){
		std::cin >> id >> tiempo;
		p.push({ id, tiempo, tiempo });
	}
	
	int K; //n�mero de env�os
	std::cin >> K;

	usuario act;
	// escribir sol
	for (int i = 0; i < K; ++i){
		act = p.top();
		act.tiempoAct += act.periodo;
		p.pop();
		std::cout << act.identificador << "\n";
		p.push(act);
	}

	std::cout << "---\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
