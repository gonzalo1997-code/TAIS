
// Marina Lozano Lahuerta
// TAIS41

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <string>

#include "PriorityQueue.h"// propios o los de las estructuras de datos de clase


struct paciente{
	std::string nombre;
	int gravedad;
	int llegada;
};


bool operator < (paciente const& p1, paciente const& p2){
	return (p1.gravedad > p2.gravedad) || (p1.gravedad == p2.gravedad) && p1.llegada < p2.llegada;
}
// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int numCasos;

	std::cin >> numCasos;
	if (numCasos == 0)
		return false;

	PriorityQueue < paciente > pacientes;

	char evento;
	int llegada = 0;

	std::string nombre;
	int gravedad;

	for (int i = 0; i < numCasos; ++i){
		std::cin >> evento;

		switch (evento){
		case 'I':
			std::cin >> nombre >> gravedad;
			pacientes.push({nombre, gravedad, llegada});
			++llegada;
			break;
		case 'A':
			paciente p = pacientes.top();
			std::cout << p.nombre << "\n";
			pacientes.pop();
			break;
		}
	}

	std::cout << "---\n";

	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
