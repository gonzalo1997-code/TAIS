
// Marina Lozano Lahuerta
// TAIS41

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>

#include "PriorityQueue.h" // propios o los de las estructuras de datos de clase

struct caja{
	int num;
	int tiempo;
};

bool operator < (caja const& c1, caja const& c2){
	return c1.tiempo < c2.tiempo || (c1.tiempo == c2.tiempo) && c1.num < c2.num;
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int numCajas, numClientes;

	std::cin >> numCajas >> numClientes;

	if (numCajas == 0 && numClientes == 0)
		return false;


	PriorityQueue<caja> cajas;
	int tiempo;

	for (int i = 0; i < numClientes; ++i){
		std::cin >> tiempo;
		if (cajas.size() < numCajas){
			cajas.push({ cajas.size(), tiempo });
		}
		else{
			caja c = cajas.top();
			tiempo += c.tiempo;
			cajas.pop();
			cajas.push({ c.num, tiempo });
		}
	}

	if (cajas.size() == numCajas){ //Todas ocupadas
		caja c = cajas.top();
		std::cout << c.num + 1 << "\n";
	}
	else{//Quedan cajas libres
		std::cout << cajas.size() + 1 << "\n";
	}

	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
