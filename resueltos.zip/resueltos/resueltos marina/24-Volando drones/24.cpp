
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <functional>
#include <vector>
#include <algorithm>

#include "PriorityQueue.h"



// funci�n que resuelve el problema
// comentario sobre el coste, O(f(N)), donde N es ...

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int numDrones, numPilasA, numPilasB;
	std::cin >> numDrones >> numPilasA >> numPilasB;
	if (!std::cin)  // fin de la entrada
		return false;

	

	PriorityQueue<int, std::greater<int>> pilasA;
	PriorityQueue<int, std::greater<int>> pilasB;
	int pila;

	for (int i = 0; i < numPilasA; ++i) {
		std::cin >> pila;
		pilasA.push(pila);
	}

	for (int i = 0; i < numPilasB; ++i) {
		std::cin >> pila;
		pilasB.push(pila);
	}
	

	std::vector<int> numHoras;
	std::vector<int> pA; //pilas A sobrantes
	std::vector<int> pB; //pilas B sobrantes

	
	while (pilasA.size() > 0 && pilasB.size() > 0) {
		int horas = 0;
		for (int i = 0; i < numDrones; ++i) {
			if (pilasA.size() > 0 && pilasB.size() > 0) {
				int pilaA = pilasA.top();
				pilasA.pop();
				int pilaB = pilasB.top();
				pilasB.pop();

				horas += std::min(pilaA, pilaB);

				if (pilaA > pilaB) {
					pA.push_back(pilaA - pilaB);
				}
				else if (pilaB > pilaA) {
					pB.push_back(pilaB - pilaA);
				}
			}
		}
		numHoras.push_back(horas);

		for (int i = 0; i < pA.size(); ++i) {
			pilasA.push(pA[i]);
		}
		pA.clear();
		for (int i = 0; i < pB.size(); ++i) {
			pilasB.push(pB[i]);
		}
		pB.clear();
	}
	// escribir sol
	std::cout << numHoras[0];
	for (int i = 1; i < numHoras.size(); ++i) {
		std::cout << " " << numHoras[i];
	}

	std::cout << "\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
