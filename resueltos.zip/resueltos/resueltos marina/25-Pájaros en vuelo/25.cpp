// Marina Lozano Lahuerta


#include <iostream>
#include <fstream>

#include "PriorityQueue.h" // propios o los de las estructuras de datos de clase



// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int edad, parejas;
	std::cin >> edad >> parejas;

	if (edad == 0 && parejas == 0)
		return false;

	PriorityQueue<int, std::greater<int>> menores;
	PriorityQueue<int> mayores;
	int p1, p2;
	std::vector<int> primero;

	int cabecera = edad;
	for (int i = 0; i < parejas; ++i) {
		std::cin >> p1 >> p2;

		if (p1 < cabecera) {
			menores.push(p1);
		}
		else {
			mayores.push(p1);
		}

		if (p2 < cabecera) {
			menores.push(p2);
		}
		else {
			mayores.push(p2);
		}

		if(menores.size() > mayores.size()){
			mayores.push(cabecera);
			cabecera = menores.top();
			menores.pop();
		}
		else if (menores.size() < mayores.size()) {
			menores.push(cabecera);
			cabecera = mayores.top();
			mayores.pop();
		}
		primero.push_back(cabecera);
	}

	// escribir sol
	std::cout << primero[0];
	for (int i = 1; i < primero.size(); ++i) {
		std::cout << " " << primero[i];
	}
	std::cout << "\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
