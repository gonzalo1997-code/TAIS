
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <functional>
#include "PriorityQueue.h"


struct musicos {
	int numParti;
	int numInstru;
	int concurrido;
};

bool operator<(musicos const& m1, musicos const& m2) {
	return m1.concurrido > m2.concurrido;
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int partituras, instrumentos;

	std::cin >> partituras >> instrumentos;
	if (!std::cin)  // fin de la entrada
		return false;

	PriorityQueue<musicos> musico;
	int inst;

	for (int i = 0; i < instrumentos; ++i) {
		std::cin >> inst;
		musico.push({1,inst,inst});
	}
	

	for (int i = 0; i < partituras-instrumentos; ++i) {
		musicos m = musico.top();
		musico.pop();
		

		++m.numParti;
		if ((m.numInstru % m.numParti) == 0) {
			m.concurrido = m.numInstru / m.numParti;
		}
		else {
			m.concurrido = (m.numInstru / m.numParti) + 1;
		}
		
		musico.push(m);
	}
	// escribir sol
	std::cout << musico.top().concurrido << "\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}