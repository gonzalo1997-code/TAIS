
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>

#include "Grafo.h"

class Bipartito {
public:
	Bipartito(Grafo const& G) : marked(G.V(), false), color(G.V(), false), _bipartito(true) {
		for (int v = 0; v < G.V(); ++v) {
			if (!marked[v]) {
				dfs(G, v);
			}
		}
	}

	bool bipartito() const {
		return _bipartito;
	}

private:
	std::vector<bool> marked;
	std::vector<bool> color;
	bool _bipartito;

	void dfs(Grafo const& G, int v) {
		marked[v] = true;


		for (int w : G.ady(v)) {
			

			if (!marked[w]) {
				if (!color[v]) {
					color[w] = true;
				}
				else {
					color[w] = false;
				}
				dfs(G, w);
			}
			else if (color[v] == color[w]) {
				_bipartito = false;
			}
			
		}

	}
};

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int vertices, aristas;

	std::cin >> vertices;
	if (!std::cin)  // fin de la entrada
		return false;

	std::cin >> aristas;

	Grafo grafo(vertices);
	int a1, a2;

	for (int i = 0; i < aristas; ++i) {
		std::cin >> a1 >> a2;
		grafo.ponArista(a1, a2);
	}

	Bipartito bipartito(grafo);

	if (bipartito.bipartito()) {
		std::cout << "SI\n";
	}
	else {
		std::cout << "NO\n";
	}
	// escribir sol

	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
