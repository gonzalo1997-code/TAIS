
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include "Grafo.h"

class colocarGuardias {
public:
	colocarGuardias(Grafo const& G) : marked(G.V(), false), guardia(G.V(), false), _posible(true), _numGuardias(0), g1(0), g2(0) {
		for (int v = 0; v < G.V(); ++v) {
			if (!marked[v]) {
				++g2;
				dfs(G, v);
				if (_posible) {
					_numGuardias += std::min(g1, g2);
				}
				else {
					_numGuardias = -1;
				}
				g1 = 0;
				g2 = 0;
			}
		}
	}

	int numGuardias() const {
		return _numGuardias;
	}

private:
	std::vector<bool>marked;
	std::vector<bool>guardia;
	int _numGuardias;
	bool _posible;
	int g1, g2;

	void dfs(Grafo const& G, int v) {
		marked[v] = true;

		for (int w : G.ady(v)) {
			if (!marked[w]) {
				if (!guardia[v]) {
					guardia[w] = true;
					++g1;
				}
				else {
					guardia[w] = false;
					++g2;
				}
				dfs(G, w);
			}
			else if (guardia[v] == guardia[w]) {
				_posible = false;
			}
		}
	}
};

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int vertices, aristas;

	std::cin >> vertices;
	if (!std::cin)  // fin de la entrada
		return false;

	std::cin >> aristas;

	Grafo grafo(vertices);
	int a1, a2;

	for (int i = 0; i < aristas; ++i) {
		std::cin >> a1 >> a2;
		grafo.ponArista(a1 - 1, a2 - 1);
	}

	colocarGuardias colocar(grafo);

	// escribir sol
	if (colocar.numGuardias() == -1) {
		std::cout << "IMPOSIBLE\n";
	}
	else {
		std::cout << colocar.numGuardias() << "\n";
	}

	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
