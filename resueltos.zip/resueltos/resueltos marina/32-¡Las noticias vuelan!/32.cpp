
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include "ConjuntosDisjuntos.h" 


// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N, M;//num usuarios en la red, num grupos.
	std::cin >> N;
	if (!std::cin)  // fin de la entrada
		return false;
	std::cin >> M;

	ConjuntosDisjuntos cd(N);
	

	int num;
	int a1, a2;
	for (int i = 0; i < M; ++i) {
		std::cin >> num;
		if (num > 1) {
			std::cin >> a1;
			std::cin >> a2;
			cd.unir(a1 - 1, a2 - 1);
			for (int j = 0; j < num - 2; ++j) {
				std::cin >> a2;
				cd.unir(a1 - 1, a2 - 1);
			}
		}
		if (num == 1) {
			std::cin >> a1;
		}
	}

	//Soluci�n
	std::cout << cd.tam(0);
	for (int i = 1; i < N; ++i) {
		std::cout << " " << cd.tam(i);
	}

	std::cout << "\n";

	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
