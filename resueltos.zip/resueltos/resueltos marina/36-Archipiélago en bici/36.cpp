
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include "GrafoValorado.h"
#include "PriorityQueue.h"

using namespace std;

class Prim {
public:

	Prim(GrafoValorado<int> const& G) : marked(G.V()), mst(), pq() {
		visit(G, 0);
		while (!pq.empty() && mst.size() < G.V() - 1) {
			Arista<int> e = pq.top(); pq.pop();
			int v = e.uno(), w = e.otro(v);
			if (marked[v] && marked[w]) continue;
			mst.push(e);
			if (!marked[v]) visit(G, v);
			if (!marked[w]) visit(G, w);
		}
		conexo = mst.size() == (G.V() - 1);
		
	}
	bool esConexo() const {
		return conexo;
	}

	int coste() {
		int solucion = 0;
		int tam = mst.size();
		for (int i = 0; i < tam; ++i) {
			solucion += mst.front().valor();
			mst.pop();
		}
		return solucion;
	}
private:
	vector<bool> marked;   // MST vertices   
	queue<Arista<int> > mst;    // MST edges   
	PriorityQueue<Arista<int> > pq;  // PQ of edges   
	bool conexo;
	

	void visit(GrafoValorado<int> const& G, int v) {
		marked[v] = true;
		for (Arista<int> e : G.ady(v))
			if (!marked[e.otro(v)])
				pq.push(e);
	}

};



// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int I, P;
	cin >> I >> P;
	if (!std::cin)  // fin de la entrada
		return false;

	GrafoValorado<int> g(I);
	int v, w, coste;
	for (int i = 0; i < P; ++i) {
		cin >> v >> w >> coste;
		g.ponArista({ v - 1, w - 1,coste });
	}

	Prim p(g);

	// escribir sol
	if (p.esConexo()) {
		cout << p.coste() << "\n";
	}
	else {
		cout << "No hay puentes suficientes\n";
	}
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
