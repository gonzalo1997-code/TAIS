
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using tablero = std::vector<std::vector<int>>;
class SerpientesyEscaleras {
public:
	SerpientesyEscaleras(tablero const& t, int s, int K) : minJugadas(0), marked(t.size(), false), distTo(t.size()) {
		bfs(t, s, K);
		minJugadas = distTo[t.size() - 1];
	}

	int minimoJugadas() const {
		return minJugadas;
	}
private:
	int minJugadas;
	std::vector<bool> marked;
	std::vector<int> distTo;

	void bfs(tablero const& G, int s, int K) {
		std::queue<int> q;
		marked[s] = true;
		distTo[s] = 0;
		q.push(s);
		while (!q.empty()) {
			int v = q.front();
			q.pop();

			for (int i = 1; i <= K && v + i < G.size(); ++i) {
				int w = v + i;

				if (!G[w].empty()) {
					w = G[w][0];
				}

				if (!marked[w]) {
					distTo[w] = distTo[v] + 1;
					marked[w] = true;
					q.push(w);
				
				}
			}
		}
	}
};

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N, K, S, E;
	std::cin >> N >> K >> S >> E;
	if (N == 0 && K == 0 && S == 0 && E == 0)
		return false;

	tablero tab(N * N);

	int ini, fin;
	for (int i = 0; i < (S + E); ++i) {
		std::cin >> ini >> fin;
		tab[ini - 1].push_back(fin - 1);
	}



	SerpientesyEscaleras se(tab, 0, K);

	// escribir sol
	std::cout << se.minimoJugadas() << "\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
