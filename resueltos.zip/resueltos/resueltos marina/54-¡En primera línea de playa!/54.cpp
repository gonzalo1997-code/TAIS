
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

struct edificio {

	int este;
	int oeste;
};

bool operator <(edificio const& e1, edificio const& e2) {
	return e1.este < e2.este || (e1.este == e2.este && e1.oeste < e2.oeste);
}
// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N;

	std::cin >> N;
	if (N==0)
		return false;

	int E, W; // Este, oeste
	
	std::vector<edificio> playa(N);

	for (int i = 0; i < N; ++i) {
		std::cin >> W >> E;
		playa[i] = { E, W };
	}

	std::sort(playa.begin(), playa.end());

	int numTunel=1;
	int tunelActual = playa[0].este;

	for (int i = 1; i < N; ++i) {

		if (tunelActual <= playa[i].oeste) {
			++numTunel;
			tunelActual = playa[i].este;
		}
	}


	// escribir sol

	std::cout << numTunel << "\n";




	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
