
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

struct pelicula {
	int tiempoIni;
	int tiempoFin;
};

bool operator <(pelicula const& p1, pelicula const& p2) {
	return p1.tiempoFin < p2.tiempoFin || (p1.tiempoFin == p2.tiempoFin && p1.tiempoIni < p2.tiempoIni);
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N; //numPeliculas

	std::cin >> N;
	if (N == 0)
		return false;

	std::string ini;
	int duracion;

	std::vector<pelicula> maraton(N);
	int minutosIni;
	int minutosFin;
	for (int i = 0; i < N; ++i) {
		minutosIni = 0;
		minutosFin = 0;
		std::cin >> ini >> duracion;

		minutosIni += ((ini[0] - '0') * 10 + (ini[1] - '0')) * 60;
		minutosIni += (ini[3] - '0') * 10 + (ini[4] - '0');

		minutosFin = minutosIni + duracion;

		maraton[i] = { minutosIni,minutosFin };

	}

	std::sort(maraton.begin(), maraton.end());

	int numPeli = 1;
	int finalPeli= maraton[0].tiempoFin;
	for (int i = 1; i < N; ++i) {
		if (finalPeli + 10 <= maraton[i].tiempoIni) {
			++numPeli;
			finalPeli = maraton[i].tiempoFin;
		}
	}



	// escribir sol

	std::cout << numPeli << "\n";

	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
