
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include "PriorityQueue.h"

struct actividad {
	int ini;
	int fin;
};

bool operator<(actividad const& a1, actividad const& a2) {
	return a1.ini < a2.ini || (a1.ini == a2.ini && a1.fin < a2.fin);
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N;

	std::cin >> N;

	if (N==0)
		return false;

	int ini, fin;


	PriorityQueue<int> pq;

	std::vector<actividad> semana;
	for (int i = 0; i < N; ++i) {
		std::cin >> ini >> fin;
		semana.push_back({ini, fin});
	}
	
	std::sort(semana.begin(), semana.end());

	pq.push(semana[0].fin);
	for (int i = 1; i < N; ++i) {
		if (semana[i].ini < pq.top()) {
			pq.push(semana[i].fin);
		}
		else {
			pq.pop();
			pq.push(semana[i].fin);
		}

	}

	// escribir sol
	std::cout << pq.size()-1 << "\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
