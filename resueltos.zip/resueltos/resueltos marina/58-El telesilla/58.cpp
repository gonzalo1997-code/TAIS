﻿
// NOMBRE Y APELLIDOS
	//ALVARO DAVID ORTIZ
	//MARINA LOZANO LAHUERTA
// comentario sobre la solución, incluyendo el análisis del coste
	//Hemos creado un vector, y lo hemos ordenado de menor a mayor, esta ordenacion tiene
	//coste O(nlogN)
	//Por otro lado, hemos recorrido el vector, emparejando las personas de menor peso (i)
	//con las de mayor peso (j), si se podian sumar ambas y dicha suma es menor que el maximo
	//entonces 'quitamos' una persona i
	//y siempre 'quitamos' una persona j
	//el recorrido de este vector es de O(N)
	//la solucion devuelve el numero de viajes minimos necesarios

	//Finalmente, el coste es nlogN + N -> O(nlogN), siendo N el numero de usuarios

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

int resolver(std::vector<int>& v, int const& MAX)
{
	std::sort(v.begin(), v.end());	//Ordena el vector de menor a mayor

	int contador = 0;	//numero de viajes
	int i = 0;	//indice para las personas con menor peso
	int j = v.size() - 1; //indice para las personas con mayor peso

	while (i < j)
	{
		if (v[i] + v[j] <= MAX)	//Si no supera el limite
		{
			i++;	//Se envia la persona de menor peso
		}

		j--;	//Se envia la persona de mayor peso
		contador++;	//Se suma 1 viaje
	}

	if (i == j)	//Si queda una persona suelta
		contador++;	//Se suma 1 viaje

	return contador;	//Se devuelve
}

bool resuelveCaso() {

	int peso_maximo, N;
	cin >> peso_maximo >> N;

	if (!cin)
		return false;

	// leer el resto de datos
	std::vector<int> v(N);

	for (int i = 0; i < N; i++)
	{
		std::cin >> v[i];
	}

	// resolver el problema (posiblemente utilizando otras funciones o clases)
	std::cout << resolver(v, peso_maximo) << '\n';
	// escribir la respuesta

	return true;
}
int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	// Resolvemos
	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
