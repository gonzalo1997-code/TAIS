
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include "Matriz.h"

int INF = 1000000000;

bool posible(int L, std::vector<int> const& longitudes) {

	std::vector<bool> posible(L + 1, false);
	posible[0] = true;

	for (int i = 1; i <= longitudes.size()-1; ++i) {
		for (int j = L; j >= longitudes[i]; --j) {
			if (longitudes[i] <= j) {
				posible[j] = posible[j] || posible[j - longitudes[i]];
			}
		}
	}

	return posible[L];
}


int numManeras(int L, std::vector<int> const& longitudes) {
	std::vector<int> maneras(L+1,0);
	maneras[0] = 1;

	for (int i = 1; i <= longitudes.size()-1; ++i) {
		for (int j = L; j >= 1; --j) {
			if (longitudes[i] <= j) {
				maneras[j] = maneras[j] + maneras[j - longitudes[i]];
			}
		}
	}

	return maneras[L];
}

int minVarillas(int L, std::vector<int> const& longitudes) {
	std::vector<int> varillas(L + 1, INF);
	varillas[0] = 0;

	for (int i = 1; i <= longitudes.size()-1; ++i) {
		for (int j = L; j >= 1; --j) {
			if (longitudes[i] <= j) {
				varillas[j] = std::min(varillas[j], varillas[j - longitudes[i]]+1);
			}
		}
	}

	return varillas[L];
}


int minCoste(int L, std::vector<int> const& costes, std::vector<int> const& longitudes) {
	std::vector<int> coste(L + 1, INF);
	coste[0] = 0;

	for (int i = 1; i <= longitudes.size() -1; ++i) {
		for (int j = L; j >= 1; --j) {
			if (longitudes[i] <= j) {
				coste[j] = std::min(coste[j], coste[j - longitudes[i]] + costes[i]);
			}
		}
	}

	return coste[L];
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N, L;
	std::cin >> N >> L;
	if (!std::cin)  // fin de la entrada
		return false;

	int longitud, coste;

	std::vector<int> lo(N + 1, 0);
	std::vector<int> co(N + 1, 0);
	for (int i = 1; i <= N; ++i) {
		std::cin >> longitud >> coste;
		lo[i] = longitud;
		co[i] = coste;
	}

	if (posible(L, lo)) {
		std::cout << "SI " << numManeras(L,lo)<< " " << minVarillas(L,lo) << " "<< minCoste(L, co, lo)<<"\n";
	}
	else {
		std::cout << "NO\n";
	}

	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
