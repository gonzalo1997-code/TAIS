
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include "Matriz.h"

using namespace std;

const int INF = 1000000000;



void resolver(int N, int pMax, int pMin, std::vector<int> const& potencia, std::vector<int> const& coste, int& costeMin, int& potenciaMin) {
	int n = N;
	Matriz<int> monedas(n + 1, pMax + 1, INF);
	monedas[0][0] = 0;

	for (int i = 1; i <= n; ++i) {
		monedas[i][0] = 0;
		for (int j = 1; j <= pMax; ++j) {
			if (potencia[i] > j)
				monedas[i][j] = monedas[i - 1][j];
			else
				monedas[i][j] = min(monedas[i - 1][j], monedas[i][j - potencia[i]] + coste[i]);

		}
	}

	costeMin = monedas[n][pMin];
	int temp = costeMin;
	potenciaMin = pMin;
	for (int i = pMin + 1; i <= pMax; i++) {
		costeMin = min(costeMin, monedas[n][i]);
		if (costeMin != temp) {
			potenciaMin = i;
			temp = costeMin;
		}
	}

}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N, pMax, pMin;
	std::cin >> N >> pMax >> pMin;
	if (!std::cin)  // fin de la entrada
		return false;


	std::vector<int> potencia(N + 1, 0);
	std::vector<int> coste(N + 1, 0);

	for (int i = 1; i <= N; ++i) {
		std::cin >> potencia[i];
	}

	for (int i = 1; i <= N; ++i) {
		std::cin >> coste[i];
	}

	int costeMin = 0;
	int potenciaMin = 0;
	resolver(N, pMax, pMin, potencia, coste, costeMin, potenciaMin);

	// escribir sol


	if (costeMin == INF) {
		cout << "IMPOSIBLE\n";
	}
	else {
		cout << costeMin << " " << potenciaMin << "\n";
	}
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
