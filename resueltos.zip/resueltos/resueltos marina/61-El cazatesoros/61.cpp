
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include "Matriz.h"

using namespace std;

struct tCofre {
	int profundidad;
	int oro;
};

void tesoro_pd(vector<tCofre>const& P, int M, int& valor, vector<bool> & cuales, int & numCofres) {
	
	int n = P.size() - 1;
	Matriz<int> tesoro(n+1, M+1, 0);
	int tiempo;
	for(int i = 1; i <= n; ++i) {
		for(int j = 1; j <= M; ++j) {
			tiempo = P[i].profundidad * 3;
			if(tiempo > j)
				tesoro[i][j] = tesoro[i-1][j];
			else
				tesoro[i][j] = std::max(tesoro[i-1][j], tesoro[i-1][j - tiempo] + P[i].oro);
		}
	}
		
	valor = tesoro[n][M];
	//c�lculo de los objetos
	int resto = M;
	for(int i = n; i >= 1; --i) {
		if(tesoro[i][resto] == tesoro[i-1][resto]) {
			//no cogemos objeto i 
			cuales[i] =false;
		}
		else{
			//s� cogemos objeto i 
			++numCofres;
			cuales[i] =true;
			resto = resto - (P[i].profundidad + P[i].profundidad * 2);
		}
	}
}


// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int T;
	std::cin >> T;
	if (!std::cin)  // fin de la entrada
		return false;

	int numCofres, pro, oro;
	std::cin >> numCofres;

	std::vector<tCofre> cofre(numCofres+1);
	for (int i = 1; i <= numCofres; ++i) {
		std::cin >> pro >> oro;
		tCofre c;
		c.profundidad = pro;
		c.oro = oro;
		cofre[i] = c;
	}

	int valor=0;
	int num=0;
	vector<bool> cuales(numCofres + 1, false);

	tesoro_pd(cofre, T, valor, cuales, num);
	// escribir sol
	std::cout << valor << "\n";
	std::cout << num << "\n";

	for (int i = 0; i < cuales.size(); ++i) {
		if (cuales[i]) {
			std::cout << cofre[i].profundidad << " " << cofre[i].oro << "\n";
		}
	}
	std::cout << "---\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
