
// Marina Lozano Lahuerta

// Comentario general sobre la soluci�n,
// explicando c�mo se resuelve el problema

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include "Matriz.h"

using namespace std;

struct tJuego {
	int puntuacion;
	int salida;
};


tJuego resolver(int N, Matriz<int> const& tablero) {

	Matriz<int> camino = tablero;

	for (int i = 1; i <= N; ++i) {
		for (int j = 1; j <= N; ++j) {
			camino[i][j] = std::max(camino[i - 1][j - 1], std::max(camino[i - 1][j], camino[i - 1][j + 1])) + camino[i][j];
		}
	}

	int max = 0;
	int pos = 0;
	for (int i = 1; i <= N; ++i) {
		if (camino[N][i] > max) {
			max = camino[N][i];
			pos = i;
		}
	}
	return { max, pos };
}

// resuelve un caso de prueba, leyendo de la entrada la
// configuraci�n, y escribiendo la respuesta
bool resuelveCaso() {

	// leer los datos de la entrada
	int N;
	cin >> N;
	if (!std::cin)  // fin de la entrada
		return false;

	Matriz<int> tablero(N + 1, N + 2, 0);
	int valor;

	for (int i = 1; i <= N; ++i) {
		for (int j = 1; j <= N; ++j) {
			cin >> valor;
			tablero[i][j] = valor;
		}
	}

	tJuego sol = resolver(N, tablero);

	// escribir sol

	cout << sol.puntuacion << " " << sol.salida << "\n";
	return true;
}

int main() {
	// ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
	std::ifstream in("casos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (resuelveCaso());

	// para dejar todo como estaba al principio
#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif
	return 0;
}
